<?php
/**
 * WordPress Yönetim Paneli — APEX ARENA Yönetim Merkezi
 * Salon Rezervasyonları, PT Randevuları, Üyelikler, İletişim Mesajları ve Hibrit AI Chatbot Ayarları
 *
 * @package ApexArena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Tek Tıkla UTF-8 Excel / CSV Rapor İndirme (v2.0.0)
 */
add_action( 'admin_init', function() {
    if ( ! isset( $_GET['apex_export_csv'] ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    check_admin_referer( 'apex_csv_export' );
    global $wpdb;
    $kind = sanitize_key( wp_unslash( $_GET['apex_export_csv'] ) );

    $configs = [
        'courts'      => [ 'table' => 'apex_court_bookings',          'file' => 'apex-salon-rezervasyonlari.csv' ],
        'pt'          => [ 'table' => 'apex_pt_appointments',         'file' => 'apex-pt-randevulari.csv' ],
        'memberships' => [ 'table' => 'apex_membership_applications', 'file' => 'apex-uyelikler.csv' ],
        'cafe'        => [ 'table' => 'apex_cafe_orders',             'file' => 'apex-kafe-siparisleri.csv' ],
        'reviews'     => [ 'table' => 'apex_reviews',                 'file' => 'apex-uye-yorumlari.csv' ],
    ];
    if ( ! isset( $configs[ $kind ] ) ) {
        return;
    }

    $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}{$configs[$kind]['table']} ORDER BY id DESC", ARRAY_A );
    header( 'Content-Type: text/csv; charset=UTF-8' );
    header( 'Content-Disposition: attachment; filename="' . $configs[ $kind ]['file'] . '"' );
    echo "\xEF\xBB\xBF"; // Excel Türkçe UTF-8 BOM
    $out = fopen( 'php://output', 'w' );
    if ( ! empty( $rows ) ) {
        fputcsv( $out, array_keys( $rows[0] ), ';' );
        foreach ( $rows as $row ) {
            fputcsv( $out, array_values( $row ), ';' );
        }
    }
    fclose( $out );
    exit;
} );

add_action( 'admin_menu', function() {
    global $wpdb;
    $pending_cafe = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_cafe_orders WHERE status = 'preparing'" );
    $new_msgs     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_contact_messages WHERE status = 'new'" );
    $badge_total  = $pending_cafe + $new_msgs;
    $menu_title   = $badge_total > 0 ? sprintf( 'APEX ARENA <span class="update-plugins count-%1$d"><span class="plugin-count">%1$d</span></span>', $badge_total ) : 'APEX ARENA';

    add_menu_page(
        'APEX ARENA Yönetim',
        $menu_title,
        'manage_options',
        'apex-arena-dashboard',
        'apex_admin_dashboard_page',
        'dashicons-superhero-alt',
        3
    );
    add_submenu_page( 'apex-arena-dashboard', 'Genel Bakış', 'Genel Bakış', 'manage_options', 'apex-arena-dashboard', 'apex_admin_dashboard_page' );
    add_submenu_page( 'apex-arena-dashboard', 'Salon Rezervasyonları', 'Salon Rezervasyonları', 'manage_options', 'apex-court-bookings', 'apex_admin_court_bookings_page' );
    add_submenu_page( 'apex-arena-dashboard', 'PT Randevuları', 'PT Randevuları', 'manage_options', 'apex-pt-appointments', 'apex_admin_pt_appointments_page' );
    add_submenu_page( 'apex-arena-dashboard', 'Üyelik Başvuruları', 'Üyelikler & Mesajlar', 'manage_options', 'apex-memberships', 'apex_admin_memberships_page' );
    add_submenu_page( 'apex-arena-dashboard', 'Kafe Siparişleri & Yorumlar', 'Kafe & Yorumlar', 'manage_options', 'apex-cafe-reviews', 'apex_admin_cafe_reviews_page' );
    add_submenu_page( 'apex-arena-dashboard', 'AI Chatbot & Tesis Ayarları', 'AI & Ayarlar', 'manage_options', 'apex-settings', 'apex_admin_settings_page' );
} );

/**
 * Genel Bakış Paneli
 */
function apex_admin_dashboard_page() {
    global $wpdb;
    $court_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_court_bookings WHERE status != 'cancelled'" );
    $ref_count   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_court_bookings WHERE needs_referee = 1 AND status != 'cancelled'" );
    $pt_count    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_pt_appointments WHERE status != 'cancelled'" );
    $mem_count   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_membership_applications WHERE status = 'active'" );
    $chat_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_chatbot_logs" );
    $rev_court   = (int) $wpdb->get_var( "SELECT COALESCE(SUM(total_price),0) FROM {$wpdb->prefix}apex_court_bookings WHERE status != 'cancelled'" );
    $rev_pt      = (int) $wpdb->get_var( "SELECT COALESCE(SUM(price),0) FROM {$wpdb->prefix}apex_pt_appointments WHERE status != 'cancelled'" );
    $rev_mem     = (int) $wpdb->get_var( "SELECT COALESCE(SUM(price),0) FROM {$wpdb->prefix}apex_membership_applications WHERE status = 'active'" );
    $rev_cafe    = (int) $wpdb->get_var( "SELECT COALESCE(SUM(total_price),0) FROM {$wpdb->prefix}apex_cafe_orders WHERE status != 'cancelled'" );
    $cafe_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}apex_cafe_orders WHERE status != 'cancelled'" );
    $rev_avg     = round( (float) $wpdb->get_var( "SELECT COALESCE(AVG(rating), 5) FROM {$wpdb->prefix}apex_reviews WHERE status = 'published'" ), 1 );
    $revenue     = $rev_court + $rev_pt + $rev_mem + $rev_cafe;
    $max_rev     = max( 1, $rev_court, $rev_pt, $rev_mem, $rev_cafe );
    $csv_nonce   = wp_create_nonce( 'apex_csv_export' );
    $ai_mode     = apex_get_effective_ai_mode();
    $ai_mode_lbl = $ai_mode === 'gemini-live' ? 'Gemini 2.5 Flash (Canlı)' : ( $ai_mode === 'openai-live' ? 'OpenAI (Canlı)' : 'Hibrit WP DB' );
    ?>
    <div class="wrap apex-admin-wrap" style="max-width:1200px;">
        <div style="background:#0f1116;color:#f5f5f7;padding:28px 32px;border-radius:16px;border:1px solid rgba(255,255,255,0.08);box-shadow:0 20px 50px rgba(0,0,0,0.22);margin:16px 0 22px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;">
            <div>
                <div style="display:inline-flex;align-items:center;gap:8px;font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#989ea9;margin-bottom:8px;">
                    <span style="width:8px;height:8px;border-radius:50%;background:#30d158;display:inline-block;"></span>
                    APEX ARENA YÖNETİM MERKEZİ · v<?php echo esc_html( APEX_VERSION ); ?>
                </div>
                <h1 style="color:#ffffff;font-weight:800;font-size:24px;margin:0;padding:0;">Spor Kompleksi Operasyon Paneli</h1>
                <p style="color:#989ea9;margin:6px 0 0;font-size:13.5px;">Salon rezervasyonları (hakem talepleri dahil), PT randevuları, üyelikler, Yoast SEO ve Gemini 2.5 AI Spor Koçu metrikleri.</p>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:999px;padding:4px 16px;" target="_blank">Canlı Siteyi Aç ↗</a>
                <a href="<?php echo esc_url( wp_logout_url( wp_login_url( admin_url( 'admin.php?page=apex-arena-dashboard' ) ) ) ); ?>" class="button" style="background:rgba(227,24,55,0.18);color:#ff8093;border-color:rgba(227,24,55,0.42);border-radius:999px;padding:4px 16px;">Güvenli Çıkış</a>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin:0 0 22px;">
            <div style="background:#0f1116;color:#fff;padding:22px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);border-top:3px solid #E31837;">
                <div style="font-size:11.5px;color:#989ea9;text-transform:uppercase;letter-spacing:0.06em;">Aktif Salon Rezervasyonu</div>
                <div style="font-size:32px;font-weight:800;margin-top:8px;"><?php echo esc_html( $court_count ); ?></div>
                <div style="font-size:12px;color:#30d158;margin-top:4px;">Hakemli Maç Talebi: <?php echo esc_html( $ref_count ); ?></div>
            </div>
            <div style="background:#0f1116;color:#fff;padding:22px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);border-top:3px solid #30d158;">
                <div style="font-size:11.5px;color:#989ea9;text-transform:uppercase;letter-spacing:0.06em;">Aktif PT Randevusu</div>
                <div style="font-size:32px;font-weight:800;margin-top:8px;"><?php echo esc_html( $pt_count ); ?></div>
                <div style="font-size:12px;color:#989ea9;margin-top:4px;">Bireysel &amp; Grupsal</div>
            </div>
            <div style="background:#0f1116;color:#fff;padding:22px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);border-top:3px solid #38BDF8;">
                <div style="font-size:11.5px;color:#989ea9;text-transform:uppercase;letter-spacing:0.06em;">Aktif Üyelikler</div>
                <div style="font-size:32px;font-weight:800;margin-top:8px;"><?php echo esc_html( $mem_count ); ?></div>
                <div style="font-size:12px;color:#989ea9;margin-top:4px;">Dijital QR Kartlı</div>
            </div>
            <div style="background:#0f1116;color:#fff;padding:22px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);border-top:3px solid #f4e268;">
                <div style="font-size:11.5px;color:#989ea9;text-transform:uppercase;letter-spacing:0.06em;">Toplam İşlem Hacmi</div>
                <div style="font-size:28px;font-weight:800;margin-top:8px;"><?php echo esc_html( apex_format_tl( $revenue ) ); ?></div>
                <div style="font-size:12px;color:#f4e268;margin-top:4px;">AI Sohbet: <?php echo esc_html( $chat_count ); ?> · <?php echo esc_html( $ai_mode_lbl ); ?></div>
            </div>
        </div>

        <!-- Gelir & Operasyon Analitik Grafiği + Tek Tıkla Excel/CSV Dışa Aktarma (v2.0.0) -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:18px;margin:0 0 22px;">
            <div style="background:#0f1116;color:#fff;padding:22px 24px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);">
                <div style="font-size:11.5px;color:#989ea9;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:14px;">GELİR DAĞILIMI (CANLI MYSQL)</div>
                <?php
                $bars = [
                    [ 'Salon Kiralama (+Hakem)', $rev_court, '#E31837' ],
                    [ 'PT Antrenmanları',        $rev_pt,    '#30d158' ],
                    [ 'Dijital Üyelikler',       $rev_mem,   '#38BDF8' ],
                    [ 'Protein Kafe (' . $cafe_count . ' sipariş)', $rev_cafe, '#f4e268' ],
                ];
                foreach ( $bars as $br ) :
                    $w = round( ( $br[1] / $max_rev ) * 100 );
                ?>
                <div style="margin-bottom:12px;">
                    <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:5px;">
                        <span><?php echo esc_html( $br[0] ); ?></span>
                        <strong><?php echo esc_html( apex_format_tl( $br[1] ) ); ?></strong>
                    </div>
                    <div style="height:8px;background:rgba(255,255,255,0.08);border-radius:99px;overflow:hidden;">
                        <div style="width:<?php echo esc_attr( max( 4, $w ) ); ?>%;height:100%;background:<?php echo esc_attr( $br[2] ); ?>;border-radius:99px;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <div style="font-size:12px;color:#989ea9;margin-top:8px;">Üye Memnuniyeti: <strong style="color:#f4e268;">★ <?php echo esc_html( $rev_avg ); ?> / 5.0</strong></div>
            </div>

            <div style="background:#0f1116;color:#fff;padding:22px 24px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);display:flex;flex-direction:column;justify-content:space-between;">
                <div>
                    <div style="font-size:11.5px;color:#989ea9;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:10px;">EXCEL / CSV RAPOR MERKEZİ &amp; KOÇ PORTALI</div>
                    <p style="font-size:13px;color:#989ea9;margin:0 0 14px;">Tüm rezervasyon, PT, üyelik, kafe ve yorum verilerini Türkçe Excel uyumlu (UTF-8 BOM) CSV olarak tek tıkla indirin.</p>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-arena-dashboard&apex_export_csv=courts&_wpnonce={$csv_nonce}" ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:8px;">⬇ Salonlar CSV</a>
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-arena-dashboard&apex_export_csv=pt&_wpnonce={$csv_nonce}" ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:8px;">⬇ PT CSV</a>
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-arena-dashboard&apex_export_csv=memberships&_wpnonce={$csv_nonce}" ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:8px;">⬇ Üyelikler CSV</a>
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-arena-dashboard&apex_export_csv=cafe&_wpnonce={$csv_nonce}" ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:8px;">⬇ Kafe CSV</a>
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-arena-dashboard&apex_export_csv=reviews&_wpnonce={$csv_nonce}" ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:8px;">⬇ Yorumlar CSV</a>
                    </div>
                </div>
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=apex-coach-portal' ) ); ?>" class="button button-primary" style="background:#E31837;border-color:#E31837;border-radius:8px;padding:4px 16px;">📊 Koç Grafik &amp; Öğrenci Panelini Aç →</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=apex-cafe-reviews' ) ); ?>" class="button" style="background:rgba(255,255,255,0.08);color:#fff;border-color:rgba(255,255,255,0.16);border-radius:8px;padding:4px 14px;">Kafe &amp; Yorumlar</a>
                </div>
            </div>
        </div>

        <p style="display:flex;gap:10px;flex-wrap:wrap;">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=apex-court-bookings' ) ); ?>" class="button button-primary" style="background:#E31837;border-color:#E31837;border-radius:8px;padding:4px 16px;">Salon Rezervasyonlarını Yönet</a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=apex-pt-appointments' ) ); ?>" class="button" style="border-radius:8px;padding:4px 16px;">PT Randevuları</a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=apex-memberships' ) ); ?>" class="button" style="border-radius:8px;padding:4px 16px;">Üyelikler &amp; Mesajlar</a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=apex-settings' ) ); ?>" class="button" style="border-radius:8px;padding:4px 16px;">AI Chatbot API &amp; Tesis Ayarları</a>
            <?php if ( defined( 'WPSEO_VERSION' ) ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpseo_dashboard' ) ); ?>" class="button" style="border-radius:8px;padding:4px 16px;">Yoast SEO Ayarları</a>
            <?php endif; ?>
        </p>
    </div>
    <?php
}

/**
 * Salon Rezervasyonları Yönetim Tablosu
 */
function apex_admin_court_bookings_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'apex_court_bookings';

    if ( isset( $_GET['apex_action'], $_GET['id'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'apex_booking_act' ) ) {
        $id  = absint( $_GET['id'] );
        $act = sanitize_key( $_GET['apex_action'] );
        if ( in_array( $act, [ 'confirmed', 'cancelled' ], true ) ) {
            $wpdb->update( $table, [ 'status' => $act ], [ 'id' => $id ] );
            echo '<div class="notice notice-success"><p>Rezervasyon durumu güncellendi.</p></div>';
        }
    }

    $rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 100" );
    ?>
    <div class="wrap">
        <h1>Salon Rezervasyonları (Basketbol 1 & 2, Voleybol + Hakem Hizmeti)</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr><th>Kod</th><th>Salon</th><th>Müşteri</th><th>Tarih & Saat</th><th>Hakem</th><th>Toplam</th><th>Durum</th><th>İşlem</th></tr>
            </thead>
            <tbody>
            <?php if ( empty( $rows ) ) : ?>
                <tr><td colspan="8">Henüz salon rezervasyonu bulunmuyor.</td></tr>
            <?php else : foreach ( $rows as $r ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $r->booking_code ); ?></strong></td>
                    <td><?php echo esc_html( $r->court_name ); ?> (<?php echo esc_html( $r->duration_hours ); ?>s)</td>
                    <td><?php echo esc_html( $r->customer_name ); ?><br><small><?php echo esc_html( $r->customer_phone ); ?> · <?php echo esc_html( $r->customer_email ); ?></small></td>
                    <td><?php echo esc_html( date( 'd.m.Y', strtotime( $r->booking_date ) ) . ' — ' . $r->time_slot ); ?></td>
                    <td><?php echo $r->needs_referee ? '<span style="background:#E31837;color:#fff;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:700;">EVET (+' . esc_html( apex_format_tl( $r->referee_fee ) ) . ')</span>' : 'Hayır'; ?></td>
                    <td><strong><?php echo esc_html( apex_format_tl( $r->total_price ) ); ?></strong></td>
                    <td><?php echo esc_html( strtoupper( $r->status ) ); ?></td>
                    <td>
                        <?php $nonce = wp_create_nonce( 'apex_booking_act' ); ?>
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-court-bookings&apex_action=confirmed&id={$r->id}&_wpnonce={$nonce}" ) ); ?>" class="button button-small">Onayla</a>
                        <a href="<?php echo esc_url( admin_url( "admin.php?page=apex-court-bookings&apex_action=cancelled&id={$r->id}&_wpnonce={$nonce}" ) ); ?>" class="button button-small">İptal</a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * PT Randevuları Yönetim Tablosu
 */
function apex_admin_pt_appointments_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'apex_pt_appointments';
    $rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 100" );
    ?>
    <div class="wrap">
        <h1>PT Eğitmen Randevuları (Bireysel & Grupsal)</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr><th>Kod</th><th>Antrenör</th><th>Tür & Paket</th><th>Müşteri</th><th>Tarih & Saat</th><th>Ücret</th><th>Durum</th></tr>
            </thead>
            <tbody>
            <?php if ( empty( $rows ) ) : ?>
                <tr><td colspan="7">Henüz PT randevusu bulunmuyor.</td></tr>
            <?php else : foreach ( $rows as $r ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $r->booking_code ); ?></strong></td>
                    <td><?php echo esc_html( $r->trainer_name ); ?></td>
                    <td><strong><?php echo esc_html( strtoupper( $r->training_type ) ); ?></strong> — <?php echo esc_html( $r->package_name ); ?></td>
                    <td><?php echo esc_html( $r->customer_name ); ?><br><small><?php echo esc_html( $r->customer_phone ); ?></small></td>
                    <td><?php echo esc_html( date( 'd.m.Y', strtotime( $r->appointment_date ) ) . ' — ' . $r->time_slot ); ?></td>
                    <td><?php echo esc_html( apex_format_tl( $r->price ) ); ?></td>
                    <td><?php echo esc_html( strtoupper( $r->status ) ); ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * Üyelikler Tablosu
 */
function apex_admin_memberships_page() {
    global $wpdb;
    $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}apex_membership_applications ORDER BY id DESC LIMIT 100" );
    $msgs = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}apex_contact_messages ORDER BY id DESC LIMIT 30" );
    ?>
    <div class="wrap">
        <h1>Üyelik Kayıtları & Başvuruları</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Üye Kodu</th><th>Ad Soyad</th><th>Paket</th><th>Periyot & Ücret</th><th>İletişim</th><th>Hedef</th><th>Durum</th></tr></thead>
            <tbody>
            <?php foreach ( $rows as $r ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $r->member_code ); ?></strong></td>
                    <td><?php echo esc_html( $r->full_name ); ?></td>
                    <td><?php echo esc_html( $r->plan_name ); ?></td>
                    <td><?php echo esc_html( $r->billing_cycle === 'annual' ? 'Yıllık' : 'Aylık' ); ?> · <?php echo esc_html( apex_format_tl( $r->price ) ); ?></td>
                    <td><?php echo esc_html( $r->phone ); ?><br><small><?php echo esc_html( $r->email ); ?></small></td>
                    <td><?php echo esc_html( $r->goal ); ?></td>
                    <td><?php echo esc_html( strtoupper( $r->status ) ); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <h2 style="margin-top:32px;">Son İletişim Mesajları</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Ad Soyad</th><th>E-posta & Tel</th><th>Konu</th><th>Mesaj</th><th>Tarih</th></tr></thead>
            <tbody>
            <?php if ( empty( $msgs ) ) : ?>
                <tr><td colspan="5">Henüz iletişim mesajı yok.</td></tr>
            <?php else : foreach ( $msgs as $m ) : ?>
                <tr>
                    <td><?php echo esc_html( $m->full_name ); ?></td>
                    <td><?php echo esc_html( $m->email ); ?><br><small><?php echo esc_html( $m->phone ); ?></small></td>
                    <td><?php echo esc_html( $m->subject ); ?></td>
                    <td><?php echo esc_html( $m->message ); ?></td>
                    <td><?php echo esc_html( $m->created_at ); ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * Hibrit AI Chatbot & Tesis Ayarları Sayfası
 */
function apex_admin_settings_page() {
    if ( isset( $_POST['apex_save_settings'] ) && check_admin_referer( 'apex_settings_nonce' ) ) {
        $new = [
            'phone'          => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
            'email'          => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
            'address'        => sanitize_text_field( wp_unslash( $_POST['address'] ?? '' ) ),
            'weekday_hours'  => sanitize_text_field( wp_unslash( $_POST['weekday_hours'] ?? '' ) ),
            'weekend_hours'  => sanitize_text_field( wp_unslash( $_POST['weekend_hours'] ?? '' ) ),
            'referee_fee'    => absint( $_POST['referee_fee'] ?? 450 ),
            'live_occupancy' => min( 100, absint( $_POST['live_occupancy'] ?? 34 ) ),
            'parking_free'   => absint( $_POST['parking_free'] ?? 118 ),
            'parking_total'  => max( 1, absint( $_POST['parking_total'] ?? 180 ) ),
            'ai_provider'    => sanitize_key( $_POST['ai_provider'] ?? 'hybrid' ),
            'gemini_api_key' => sanitize_text_field( wp_unslash( $_POST['gemini_api_key'] ?? '' ) ),
            'gemini_model'   => sanitize_text_field( wp_unslash( $_POST['gemini_model'] ?? 'gemini-2.5-flash' ) ),
            'openai_api_key' => sanitize_text_field( wp_unslash( $_POST['openai_api_key'] ?? '' ) ),
            'openai_model'   => sanitize_text_field( wp_unslash( $_POST['openai_model'] ?? 'gpt-4o-mini' ) ),
            'github_url'     => esc_url_raw( wp_unslash( $_POST['github_url'] ?? '' ) ),
            'envato_url'     => esc_url_raw( wp_unslash( $_POST['envato_url'] ?? '' ) ),
        ];
        update_option( 'apex_arena_settings', $new );
        echo '<div class="notice notice-success"><p><strong>APEX ARENA ayarları başarıyla kaydedildi!</strong></p></div>';
    }
    $s = apex_get_settings();
    ?>
    <div class="wrap">
        <h1>APEX ARENA — Hibrit AI Spor Koçu & Tesis Ayarları</h1>
        <form method="post">
            <?php wp_nonce_field( 'apex_settings_nonce' ); ?>
            <h2>1. Hibrit AI Spor Koçu (Chatbot) Yapılandırması</h2>
            <p class="description">API anahtarı girildiğinde canlı Google Gemini / OpenAI LLM + gerçek WordPress veritabanı RAG çalışır. Anahtar boş bırakılırsa sistem sıfır hata ile Yerel Akıllı Türkçe NLP + Canlı WP DB motoruna otomatik geçer.</p>
            <table class="form-table">
                <tr><th>AI Çalışma Modu</th><td>
                    <select name="ai_provider">
                        <option value="hybrid" <?php selected( $s['ai_provider'], 'hybrid' ); ?>>Otomatik Hibrit (API varsa LLM, yoksa Yerel WP DB)</option>
                        <option value="gemini" <?php selected( $s['ai_provider'], 'gemini' ); ?>>Google Gemini API</option>
                        <option value="openai" <?php selected( $s['ai_provider'], 'openai' ); ?>>OpenAI ChatGPT API</option>
                        <option value="local" <?php selected( $s['ai_provider'], 'local' ); ?>>Sadece Yerel Akıllı WP DB Motoru (Offline)</option>
                    </select>
                </td></tr>
                <tr><th>Google Gemini API Anahtarı</th><td><input type="password" name="gemini_api_key" class="regular-text" value="<?php echo esc_attr( $s['gemini_api_key'] ); ?>" autocomplete="off"> <input type="text" name="gemini_model" value="<?php echo esc_attr( $s['gemini_model'] ); ?>" placeholder="gemini-2.5-flash"></td></tr>
                <tr><th>OpenAI API Anahtarı</th><td><input type="password" name="openai_api_key" class="regular-text" value="<?php echo esc_attr( $s['openai_api_key'] ); ?>" autocomplete="off"> <input type="text" name="openai_model" value="<?php echo esc_attr( $s['openai_model'] ); ?>" placeholder="gpt-4o-mini"></td></tr>
            </table>

            <h2>2. Tesis & Salon Ayarları</h2>
            <table class="form-table">
                <tr><th>Hakem Ayarlama Ücreti (₺)</th><td><input type="number" name="referee_fee" value="<?php echo esc_attr( $s['referee_fee'] ); ?>"></td></tr>
                <tr><th>Canlı Tesis Yoğunluğu (%)</th><td><input type="number" min="0" max="100" name="live_occupancy" value="<?php echo esc_attr( $s['live_occupancy'] ); ?>"></td></tr>
                <tr><th>Otopark Boş / Toplam</th><td><input type="number" name="parking_free" class="small-text" value="<?php echo esc_attr( $s['parking_free'] ); ?>"> / <input type="number" name="parking_total" class="small-text" value="<?php echo esc_attr( $s['parking_total'] ); ?>"></td></tr>
                <tr><th>Telefon</th><td><input type="text" name="phone" class="regular-text" value="<?php echo esc_attr( $s['phone'] ); ?>"></td></tr>
                <tr><th>E-posta</th><td><input type="email" name="email" class="regular-text" value="<?php echo esc_attr( $s['email'] ); ?>"></td></tr>
                <tr><th>Adres</th><td><input type="text" name="address" class="large-text" value="<?php echo esc_attr( $s['address'] ); ?>"></td></tr>
                <tr><th>Hafta İçi / Hafta Sonu Saatleri</th><td><input type="text" name="weekday_hours" value="<?php echo esc_attr( $s['weekday_hours'] ); ?>"> / <input type="text" name="weekend_hours" value="<?php echo esc_attr( $s['weekend_hours'] ); ?>"></td></tr>
                <tr><th>GitHub Deposu Linki</th><td><input type="url" name="github_url" class="large-text" value="<?php echo esc_attr( $s['github_url'] ); ?>"></td></tr>
                <tr><th>Envato / ThemeForest Linki</th><td><input type="url" name="envato_url" class="large-text" value="<?php echo esc_attr( $s['envato_url'] ); ?>"></td></tr>
            </table>
            <p class="submit"><button type="submit" name="apex_save_settings" class="button button-primary button-large">Ayarları Kaydet</button></p>
        </form>
    </div>
    <?php
}

/**
 * Kafe Ön Siparişleri & Üye Yorumları Yönetim Sayfası (v2.0.0)
 */
function apex_admin_cafe_reviews_page() {
    global $wpdb;
    $t_cafe = $wpdb->prefix . 'apex_cafe_orders';
    $t_rev  = $wpdb->prefix . 'apex_reviews';

    if ( isset( $_GET['cafe_status'], $_GET['id'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'apex_cr_act' ) ) {
        $st = sanitize_key( $_GET['cafe_status'] );
        if ( in_array( $st, [ 'preparing', 'ready', 'completed', 'cancelled' ], true ) ) {
            $wpdb->update( $t_cafe, [ 'status' => $st ], [ 'id' => absint( $_GET['id'] ) ] );
            echo '<div class="notice notice-success"><p>Kafe sipariş durumu güncellendi.</p></div>';
        }
    }
    if ( isset( $_GET['rev_status'], $_GET['id'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'apex_cr_act' ) ) {
        $st = sanitize_key( $_GET['rev_status'] );
        if ( in_array( $st, [ 'published', 'hidden' ], true ) ) {
            $wpdb->update( $t_rev, [ 'status' => $st ], [ 'id' => absint( $_GET['id'] ) ] );
            echo '<div class="notice notice-success"><p>Yorum yayın durumu güncellendi.</p></div>';
        }
    }

    $orders  = $wpdb->get_results( "SELECT * FROM {$t_cafe} ORDER BY id DESC LIMIT 50" );
    $reviews = $wpdb->get_results( "SELECT * FROM {$t_rev} ORDER BY id DESC LIMIT 50" );
    $nonce   = wp_create_nonce( 'apex_cr_act' );
    ?>
    <div class="wrap">
        <h1>Apex Protein Kafe Ön Siparişleri</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Kod</th><th>Müşteri</th><th>Teslim Zamanı</th><th>Ürünler &amp; Makro</th><th>Tutar</th><th>Durum</th><th>İşlem</th></tr></thead>
            <tbody>
            <?php if ( empty( $orders ) ) : ?>
                <tr><td colspan="7">Henüz kafe ön siparişi yok.</td></tr>
            <?php else : foreach ( $orders as $o ) :
                $its = json_decode( (string) $o->items_json, true ) ?: [];
                $lbl = implode( ', ', array_map( fn( $x ) => ( $x['qty'] ?? 1 ) . 'x ' . ( $x['name'] ?? '' ), $its ) );
            ?>
                <tr>
                    <td><strong><?php echo esc_html( $o->order_code ); ?></strong></td>
                    <td><?php echo esc_html( $o->customer_name ); ?><br><small><?php echo esc_html( $o->customer_phone ); ?></small></td>
                    <td><?php echo esc_html( $o->pickup_time ); ?></td>
                    <td><?php echo esc_html( $lbl ); ?><br><small><?php echo esc_html( $o->total_kcal ); ?> kcal · <?php echo esc_html( $o->total_protein ); ?>g protein</small></td>
                    <td><strong><?php echo esc_html( apex_format_tl( $o->total_price ) ); ?></strong></td>
                    <td><strong><?php echo esc_html( strtoupper( $o->status ) ); ?></strong></td>
                    <td>
                        <a class="button button-small" href="<?php echo esc_url( admin_url( "admin.php?page=apex-cafe-reviews&cafe_status=ready&id={$o->id}&_wpnonce={$nonce}" ) ); ?>">Hazır</a>
                        <a class="button button-small" href="<?php echo esc_url( admin_url( "admin.php?page=apex-cafe-reviews&cafe_status=completed&id={$o->id}&_wpnonce={$nonce}" ) ); ?>">Teslim</a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>

        <h2 style="margin-top:32px;">Üye Yorumları &amp; Puanlamalar</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Üye</th><th>Paket</th><th>Puan</th><th>Yorum</th><th>Durum</th><th>İşlem</th></tr></thead>
            <tbody>
            <?php foreach ( $reviews as $rv ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $rv->author_name ); ?></strong></td>
                    <td><?php echo esc_html( $rv->member_plan ); ?></td>
                    <td>★ <?php echo esc_html( $rv->rating ); ?> / 5</td>
                    <td><?php echo esc_html( $rv->comment ); ?></td>
                    <td><?php echo esc_html( strtoupper( $rv->status ) ); ?></td>
                    <td>
                        <?php if ( $rv->status === 'published' ) : ?>
                            <a class="button button-small" href="<?php echo esc_url( admin_url( "admin.php?page=apex-cafe-reviews&rev_status=hidden&id={$rv->id}&_wpnonce={$nonce}" ) ); ?>">Gizle</a>
                        <?php else : ?>
                            <a class="button button-small" href="<?php echo esc_url( admin_url( "admin.php?page=apex-cafe-reviews&rev_status=published&id={$rv->id}&_wpnonce={$nonce}" ) ); ?>">Yayınla</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
